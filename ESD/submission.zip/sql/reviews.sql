SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


DROP DATABASE IF EXISTS reviews;
CREATE DATABASE reviews;
USE reviews;

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE IF NOT EXISTS `reviews` (
  `RID` int(11) NOT NULL AUTO_INCREMENT,
  `crUsername` varchar(128) NOT NULL,
  `carPlateNo` varchar(10) NOT NULL,
  `reviewContents` varchar(1000) NOT NULL,
  PRIMARY KEY (`RID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


INSERT INTO `reviews` (`RID`, `crUsername`, `carPlateNo`, `reviewContents`) 
VALUES
(1, 'amy111', 'sku8882c', 'Nice car, great owner!'),
(2, 'bebe111', 'sku8883c', 'Clean but old'),
(3, 'cutie111', 'sku8888d', 'Pretty owner : - )'),
(4, 'doggy111', 'sku8882c', 'Wow even prettier owner.'),
(5, 'ugly111', 'sku8883c', 'Try harder next time, car quite bad....');

COMMIT;
