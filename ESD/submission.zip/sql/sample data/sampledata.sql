INSERT INTO `reviews` (`RID`, `crUsername`, `carPlateNo`, `reviewContents`) VALUES 
('1', 'UN1', 'SHX0001D', 'Good car.'), 
('2', 'UN2', 'SHX0002D', 'Amazing car.'), 
('3', 'UN3', 'SHX0003D', 'Such beautiful boot.'), 
('4', 'UN4', 'SHX0001D', 'Will rent again.');

INSERT INTO car (cid,carplateno,cousername,brand,model,colour,capacity,transmissiontype,hourlyrate) VALUES
 (1, 'sku8882c', 'fiona', 'Audi', 'R8', 'Black','2', 'manual', 30),
 (2, 'sku8888d', 'chanel', 'Range Rover', 'V6', 'White','7', 'manual', 25),
 (3, 'sku8883c', 'betaced', 'Honda', '338', 'Purple','5', 'auto', 15);

 insert into caravailability (carPlateNo,availableStartDate,availableEndDate,carStatus) VALUES
('sku8882c', "2020-03-14", "2020-04-14", 'available'),
('sku8888d', "2020-03-14", "2020-03-20", 'available'),
('sku8883c', "2020-03-20", "2020-05-31", 'available');